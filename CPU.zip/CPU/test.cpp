#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>


int main (void) {

	/*

	char * buffer = "hello    5";
	char str1 [10];
	char str2 [10];

	sscanf (buffer, "%s %s", str1, str2); 
	printf ("%s\n", str1);
	printf ("%s\n", str2);

	*/

	/*

	char getAdress [50] = "jb 2 :start";
	char arg [50];
    int lenStr = 0, val = 0, numStr = 0;

    sscanf (getAdress, "%s%n", arg, &lenStr);
    while (isspace (*(getAdress + lenStr)))
        lenStr++;
    printf ("lenStr: %d\n", lenStr);
    sscanf (getAdress + lenStr, "%d%n", &val, &numStr);
    printf ("num: %d\nnumStr: %d\n", val, numStr + lenStr);
    sscanf (getAdress + numStr + lenStr, "%s", arg);
    puts (arg);

    */

    int a = 3; // 011
    int b = abs (~a);
    printf ("%d %d", a, b);

}