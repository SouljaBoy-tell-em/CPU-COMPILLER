#include <stdio.h>


int main (void) {

	char * buffer = "hello    5";
	char str1 [10];
	char str2 [10];

	sscanf (buffer, "%s %s", str1, str2); 
	printf ("%s\n", str1);
	printf ("%s\n", str2);

}