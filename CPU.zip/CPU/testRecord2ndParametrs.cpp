#include <stdio.h>
#include <string.h>


int main (void) {

	/*

	int a = 0;
	scanf ("%d %d", &a, &a);
	printf ("%d", a);

	*/


    char capacityBuffer [20] = "hello: World";
    int startLabel = (int) (strchr (capacityBuffer, ':') - capacityBuffer);
    printf ("%d", startLabel);

}