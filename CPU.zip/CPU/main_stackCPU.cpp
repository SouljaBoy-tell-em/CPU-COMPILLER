//\file
///\/brief This file can show "The STACK program."


#include "head_stackCPU.h"
#include "stackCPU.h"


int main (void) {

	Stack stack = {};
	STACKNAME (stack.name, stack);
	dumpFileCleaning ();
	StackCtor (&stack, 45);
	

	for (int i = 0; i < 30; i++)
		StackPush (&stack, (Elem_t) (i + 1));

	//for (int i = 0; i < 3; i++)
	//	StackPop (&stack);

	return 0;
}
