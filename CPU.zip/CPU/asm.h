unsigned int amountOfString (char * mem, unsigned long filesize) {

    unsigned long indexFile = 0, amount = 0;
    for (indexFile = 0; indexFile < filesize; indexFile++)
        if ( * (mem + indexFile) == '\0')
            amount++;

    return amount + 1;
}


void closeMemoryPointers (FILE * compFile, FILE * fileDecompilation, FILE * binaryFile, char * mem_start,\
                          char ** getAdress, int * commandsArray, Label * labels, Register * registers)  {

    fclose (compFile);
    fclose (fileDecompilation);
    fclose (binaryFile);
    free (mem_start);
    free (getAdress);
    free (commandsArray);
    free (labels);
    free (registers);
}


void compile (int * commandsArray, char ** getAdress, unsigned long amount_of_strings, Label * labels, Register * registers) {

    char capacityBuffer [MAXLENCOMMAND];
    int numString = 0, val = 0, j = 0;

    for (numString = 0; numString < amount_of_strings; numString++) {

        sscanf (getAdress [numString], "%s", capacityBuffer);
        getAssemblerCommands (capacityBuffer, commandsArray, getAdress [numString], labels, numString, registers);
    }
}


bool createCommandsArray (int ** bufferNumberCommands, unsigned long amount_of_strings, Label ** labels) {

    * bufferNumberCommands = (int * ) calloc (2 * amount_of_strings + 2, sizeof (int));
    * labels = (Label * ) calloc (1, sizeof (Label));
    ** bufferNumberCommands = SIGNATURE;
    * ( * bufferNumberCommands + 1) = VERSION;
    ( * labels)->ip = 2;
    
    if (bufferNumberCommands == NULL)
        return false;

    return true;
}


void createRegisters (Register * registers) {

    char startRegister [LENREGISTER] = "rax";

    int i = 0;
    for (i = 0; i < AMOUNTREGISTERS; i++) {

        strcpy ((registers + i)->name, startRegister);
        startRegister [1]++;
    }
}


void decompilation (int * commandsArray, Label * labels, FILE * fileDecompilation, unsigned long sizeCommandsArray, Register * registers) {

    int flagCommands = 0;
    int i = 0;
    for (i = 2; i < sizeCommandsArray; i++) 
        decompilationCommand (commandsArray [i], fileDecompilation, &flagCommands, registers);
}


void decompilationCommand (int command, FILE * fileDecompilation, int * flagCommands, Register * registers) {

    //--------------SIMPLE COMMANDS--------------//

    if ( * flagCommands == 0) {

        if (command == ADD)
            fprintf (fileDecompilation, "add\n" );

        if (command == SUB)
            fprintf (fileDecompilation, "sub\n" );

        if (command == MUL)
            fprintf (fileDecompilation, "mul\n" );

        if (command == DIV)
            fprintf (fileDecompilation, "div\n" );

        if (command == DUMP)
            fprintf (fileDecompilation, "dump\n");

        if (command == ENDL)
            fprintf (fileDecompilation, "endl\n");

        if (command == SPACE)
            fprintf (fileDecompilation, "space\n");

        if (command == OUT)
            fprintf (fileDecompilation, "out\n" );

        if (command == HLT)
            fprintf (fileDecompilation, "hlt\n" );
    }

    //-------------------------------------------//

    if ( * flagCommands == MASKIMMED) {

        fprintf (fileDecompilation, "%d\n", command);
        * flagCommands = 0;
        return;
    }

    if ( * flagCommands == MASKREGISTER) {

        fprintf (fileDecompilation, "%s\n", (registers + command)->name);
        * flagCommands = 0;
        return;
    }

    if ( * flagCommands == 4) {

        fprintf (fileDecompilation, "[%d]\n", command);
        * flagCommands = 0;
        return;
    }

    if ( * flagCommands == 5) {

        fprintf (fileDecompilation, "[%s]\n", (registers + command)->name);
        * flagCommands = 0;
        return;
    }

    if ( * flagCommands == 2) {

        fprintf (fileDecompilation, "(%d)\n", command);
        * flagCommands = 0;
        return;
    }

    if ( * flagCommands == 3) {

        fprintf (fileDecompilation, "%d\n", command);
        * flagCommands = 0;
        return;
    }

    if ((command & TURNOFFMASKIMMED) == PUSH) {

        fprintf (fileDecompilation, "push ");
        * flagCommands = MASKIMMED;
        return;
    }

    if ((command & TURNOFFMASKREGISTER) == PUSH) {

        fprintf (fileDecompilation, "push ");
        * flagCommands = MASKREGISTER;
        return;
    }

    if ((command & TURNOFFMASKRAM) == (MASKIMMED | PUSH) || (command & TURNOFFMASKRAM) == (MASKREGISTER | PUSH)) {

        command = command & TURNOFFMASKRAM;

        if ((command & TURNOFFMASKIMMED) == PUSH)
            * flagCommands = 4;

        if ((command & TURNOFFMASKREGISTER) == PUSH)
            * flagCommands = 5;

        fprintf (fileDecompilation, "push ");
        return;
    }

    if ((command & TURNOFFMASKPOP) == POP) {

        fprintf (fileDecompilation, "pop\n");
        return;
    }

    if ((command & TURNOFFMASKIMMED) == POP) {

        fprintf (fileDecompilation, "pop ");
        * flagCommands = MASKIMMED;
        return;
    }

    if ((command & TURNOFFMASKREGISTER) == POP) {

        fprintf (fileDecompilation, "pop ");
        * flagCommands = MASKREGISTER;
        return;
    }

    if ((command & TURNOFFMASKRAM) == (MASKIMMED | POP) || (command & TURNOFFMASKRAM) == (MASKREGISTER | POP)) {

        command = command & TURNOFFMASKRAM;

        if ((command & TURNOFFMASKIMMED) == POP)
            * flagCommands = 4;

        if ((command & TURNOFFMASKREGISTER) == POP)
            * flagCommands = 5;

        fprintf (fileDecompilation, "pop ");
        return;
    }


    if (command == IN) {

        fprintf (fileDecompilation, "in ");
        * flagCommands = 2;
    }

    if (command == JMP) {

        fprintf (fileDecompilation, "jmp ");
        * flagCommands = 3;
    }

    if (command == JB) {

        fprintf (fileDecompilation, "jb ");
        * flagCommands = 3;
    }

    if (command == JBE) {

        fprintf (fileDecompilation, "jbe ");
        * flagCommands = 3;
    }

    if (command == JA) {

        fprintf (fileDecompilation, "ja ");
        * flagCommands = 3;
    }

    if (command == JAE) {

        fprintf (fileDecompilation, "jae ");
        * flagCommands = 3;
    }

    if (command == JE) {

        fprintf (fileDecompilation, "je ");
        * flagCommands = 3;
    }

    if (command == JNE) {

        fprintf (fileDecompilation, "jne ");
        * flagCommands = 3;
    }
}


int detect2ndLabel (char * getAdress, Label * labels) {

    int startLabel = (int) (strchr (getAdress, ':') - getAdress);
    char capacityBuffer [MAXLENCOMMAND];
    strcpy (capacityBuffer, getAdress + startLabel + 1);
    
    int i = 0;
    for (i = 0; i < labels->ip; i++)
        if (strcmp (capacityBuffer, (labels->arrayLabels)[i].name) == 0)
            return (labels->arrayLabels)[i].numberStringLabel;

    return -1;
}


int exploreRegister (char * arg, Register * registers) {

    if ( * arg != 'r' || * (arg + 2) != 'x')
        return -1;

    char secondLetterStartRegister = 'a';

    int i = 0;
    for (i = 0; i < AMOUNTREGISTERS; i++) {

        if ( * (arg + 1) == secondLetterStartRegister)
            return i;

        secondLetterStartRegister++;
    }

    return -1;
}   


unsigned long FileSize (FILE * compfile) {

    struct stat buf = {};
    if (fstat (fileno (compfile), &buf) == 0)
        return buf.st_size;

    return 0;
}


void getAssemblerCommands (char * capacityBuffer, int * commandsArray, char * getAdress, Label * labels, int numString, Register * registers) {

    int lenNameLabel = strlen (capacityBuffer), val = 0;
    static int j = 2;

    if (capacityBuffer [lenNameLabel - 1] == ':') {

        strncpy ((labels->arrayLabels[labels->ip]).name, capacityBuffer, lenNameLabel - 1);
        labels->arrayLabels[labels->ip].numberStringLabel = j;
        labels->ip++;
        return;
    }

    if (!strcmp ("push", capacityBuffer)   ) {

        commandsArray [j] =   PUSH;
        val = get2ndArg (getAdress, registers, &commandsArray [j]);
        j++; 
        commandsArray [j] = val;  j++;
    }

    if (!strcmp ("add", capacityBuffer)    ) {

        commandsArray [j] =   ADD;     j++;
    }

    if (!strcmp ("sub", capacityBuffer)    ) {

        commandsArray [j] =   SUB;     j++;
    }

    if (!strcmp ("mul", capacityBuffer)    ) {

        commandsArray [j] =   MUL;     j++;
    }

    if (!strcmp ("div", capacityBuffer)    ) {

        commandsArray [j] =   DIV;     j++;
    }

    if (!strcmp ("in", capacityBuffer)     ) {

        commandsArray [j] =   IN;      j++;

        if (scanf ("%d", &val) == 0)
            exit (EXIT_FAILURE);

        commandsArray [j] = val;       j++;  
    }

    if (!strcmp ("jmp", capacityBuffer)    ) {

        commandsArray [j] =   JMP;     j++;
        val = detect2ndLabel (getAdress, labels);
        commandsArray [j] = val;       j++;
    }

    if (!strcmp ("dump", capacityBuffer)   ) {

        commandsArray [j] =   DUMP;    j++;
    }

    if (!strcmp ("out", capacityBuffer)    ) {

        commandsArray [j] =   OUT;     j++;
    }

    if (!strcmp ("hlt", capacityBuffer)    ) {

        commandsArray [j] =  HLT;      j++;
    }

    if (!strcmp ("pop", capacityBuffer)    ) {

        commandsArray [j] = POP;

        if (!popEmptyArg (getAdress, &commandsArray[j])) {

            j++;
            commandsArray [j] = POISON;
            j++;
            return;
        }
        
        val = get2ndArg (getAdress, registers, &commandsArray [j]);
        j++; 
        commandsArray [j] = val;  
        j++;
    }

    if (!strcmp ("endl", capacityBuffer)   ) {

        commandsArray [j] = ENDL;        j++;
    }

    if (!strcmp ("space", capacityBuffer)      ) {

        commandsArray [j] = SPACE;       j++;
    }


    //------------JUMP FUNCTION--------------//

    if (!strcmp ("jb", capacityBuffer)     ) {

        commandsArray [j] = JB;        j++;
        val = detect2ndLabel (getAdress, labels);
        commandsArray [j] = val;       j++;
    }

    if (!strcmp ("jbe", capacityBuffer)    ) {

        commandsArray [j] = JBE;       j++;
        val = detect2ndLabel (getAdress, labels);
        commandsArray [j] = val;       j++;
    }

    if (!strcmp ("ja", capacityBuffer)    ) {

        commandsArray [j] = JA;        j++;
        val = detect2ndLabel (getAdress, labels);
        commandsArray [j] = val;       j++;
    }

    if (!strcmp ("jae", capacityBuffer)    ) {

        commandsArray [j] = JAE;       j++;
        val = detect2ndLabel (getAdress, labels);
        commandsArray [j] = val;       j++;
    }

    if (!strcmp ("je", capacityBuffer)    ) {

        commandsArray [j] = JE;        j++;
        val = detect2ndLabel (getAdress, labels);
        commandsArray [j] = val;       j++;
    }

    if (!strcmp ("jne", capacityBuffer)    ) {

        commandsArray [j] = JNE;       j++;
        val = detect2ndLabel (getAdress, labels);
        commandsArray [j] = val;       j++;
    }

    //---------------------------------------//

}


unsigned int getBuffer (char ** mem_start, unsigned long filesize,\
                            unsigned long * amount_of_string, FILE * file) {

    * mem_start = (char * ) calloc (filesize, sizeof (char));
    CHECK_ERROR (* mem_start == NULL, "Memory not allocated for mem_start.");
    fread (* mem_start, sizeof (char), filesize, file);
    recordInBuffer (* mem_start);
    * amount_of_string = amountOfString (* mem_start, filesize);

    return NO_ERROR;
}


unsigned int get2ndArg (char * getAdress, Register * registers, int * commandArray) {

    char arg [MAXLENCOMMAND];
    int lenStr = 0, val = 0;

    sscanf (getAdress, "%s%n", arg, &lenStr);
    while (isspace ( * (getAdress + lenStr)))
        lenStr++;


    sscanf (getAdress + lenStr, "%s", arg); // !!! TODO: пробелы в регистрах

    if ( * arg == '[' && * (arg + strlen (arg) - 1) == ']') {

        * (getAdress + lenStr) = * (getAdress + lenStr + strlen (arg) - 1) = ' ';
        * commandArray = ( * commandArray) | MASKRAM;
    }

    if (sscanf (getAdress, "%s %d", arg, &val) == 2) {

        * commandArray = ( * commandArray) | MASKIMMED;
        return val;
    } 

    if (sscanf (getAdress, "%s %s", arg, arg) == 2) {

        if ((val = exploreRegister (arg, registers)) >= 0)
            * commandArray = ( * commandArray) | MASKREGISTER;

        return val;
    }

    return BAD_EQUATION;
}


unsigned int InitializePointersArray (char *** getAdress, char * mem_start, unsigned long filesize,\
                              unsigned long amount_of_string) {

    * getAdress = (char ** )calloc (amount_of_string, sizeof (char * ));
    CHECK_ERROR (* getAdress == NULL, "Memory not allocated for getAdress.");
    pointerGetStr (mem_start, * getAdress, filesize);

    return NO_ERROR;
}


unsigned int InitializeStructRegistersArray (Register ** registers) {

    * registers = (Register * )calloc (AMOUNTREGISTERS, sizeof (Register));
    CHECK_ERROR (* registers == NULL, "Memory not allocated for registers.");

    return NO_ERROR;
}


void pointerGetStr (char * buffer, char ** getAdress, unsigned long filesize) {

    getAdress [0] = &buffer [0];
    
    unsigned long i = 1, j = 1;
    for (i = 0; i < filesize; i++) {
        if (buffer[i] == '\0') {

            getAdress [j] = &buffer [i+1];
            j++;
        }
    }
}


bool popEmptyArg (char * getAdress, int * commandsArray) {

    char arg [MAXLENCOMMAND];
    int lenStr = 0, val = 0;

    sscanf (getAdress, "%s%n", arg, &lenStr);

    while (isspace ( * (getAdress + lenStr)))
        lenStr++;

    if (lenStr == strlen (getAdress)) {

        * commandsArray = ( * commandsArray) | MASKPOP;
        return false;
    }

    return true;
}


void recordInBuffer (char * mem_start) {

    int amount_of_symbols = strlen (mem_start);
    for (int i = 0; i < amount_of_symbols; i++) {

        if (mem_start[i] == EOF)
            mem_start[i] = '\0';

        if (mem_start [i] == '\n') {

            mem_start[i] = '\0';
            continue;
        }
    }

}