#include <limits.h>
#include <stdint.h>
#include <stdarg.h>
#include "foundation.h"


int addingInStack (Stack * stack, int * commandsArray, Register * registers, int * ramElements, int amount_commands);
int createRAM (int ** ramElements);
bool createRegisters (Register * registers);
void detectPush (int * commandsArray, int * ip, Register * registers, Stack * stack, int * ramElements);
void dumpFileCleaning (void);
void errorsDecoder (Stack * stack, FILE * dump);
int exploreRegister (char * arg, Register * registers);
unsigned long FileSize (FILE * compfile);
unsigned int fullCodeError (Stack * stack);
uint8_t * getStartData (Stack * stack);
void InitializeCommamdsArray (int * commandsArray, int amount_commands);
unsigned int InitializeStructRegistersArray (Register ** registers);
void StackClear (Stack * stack);
void StackCtor (Stack * stack, int capacity);
void StackDump (Stack * stack, int lineStackDump, const char * nameFunctionDump, const char * fileFunctionDump);
void StackError (Stack * stack);
void StackInfoDump (Stack * stack, FILE * dump);
Elem_t StackPop (Stack * stack);
void StackPush (Stack * stack, Elem_t addDataElement);
void StackReSizeDown (Stack * stack);
void StackReSizeUp (Stack * stack, Elem_t addDataElement);
bool theEndJB (Register * registers, Stack * stack, int * commandsArray, int * i);
bool theEndJBE (Register * registers, Stack * stack, int * commandsArray, int * i);
void UninititalizeElements (Stack * stack);