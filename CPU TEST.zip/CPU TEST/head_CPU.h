#include <limits.h>
#include <stdint.h>
#include "foundation.h"

/*-----------COMMANDS CPU-----------*/

enum commands {

    CMD_PUSH = 1,
    CMD_ADD,
    CMD_SUB,
    CMD_MUL,
    CMD_DIV,
    CMD_IN,
    CMD_OUT,
    CMD_HLT,
    CMD_POP,
    CMD_JB,
    CMD_JBE,
    CMD_JA,
    CMD_JAE,
    CMD_JE,
    CMD_JNE,
    CMD_ENDL,
    CMD_SPACE,
    CMD_JMP,
    CMD_DUMP
};

/*----------------------------------*/


int addingInStack (Stack * stack, int * commandsArray, Register * registers, int * ramElements, int amount_commands);
int createRAM (int ** ramElements);
bool createRegisters (Register * registers);
bool detectPush (int * commandFlag, int commandsArray, Register * registers, Stack * stack, int * ramElements);
void dumpFileCleaning (void);
void errorsDecoder (Stack * stack, FILE * dump);
int exploreRegister (char * arg, Register * registers);
void firstArgCommands (int commandsArray, Stack * stack);
unsigned long FileSize (FILE * compfile);
unsigned int fullCodeError (Stack * stack);
uint8_t * getStartData (Stack * stack);
void InitializeCommamdsArray (int * commandsArray, int amount_commands);
unsigned int InitializeStructRegistersArray (Register ** registers);
void StackClear (Stack * stack);
void StackCtor (Stack * stack, int capacity);
void StackDump (Stack * stack, int lineStackDump, const char * nameFunctionDump, const char * fileFunctionDump);
void StackError (Stack * stack);
void StackInfoDump (Stack * stack, FILE * dump);
Elem_t StackPop (Stack * stack);
void StackPush (Stack * stack, Elem_t addDataElement);
void StackReSizeDown (Stack * stack);
void StackReSizeUp (Stack * stack, Elem_t addDataElement);
bool theEndJB (Register * registers, Stack * stack, int * commandsArray, int * i);
bool theEndJBE (Register * registers, Stack * stack, int * commandsArray, int * i);
void UninititalizeElements (Stack * stack);